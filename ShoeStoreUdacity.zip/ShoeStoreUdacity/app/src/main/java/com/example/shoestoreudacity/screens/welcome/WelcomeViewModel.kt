package com.example.shoestoreudacity.screens.welcome

import androidx.lifecycle.ViewModel

class WelcomeViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}