package com.example.shoestoreudacity.screens.instructions

import androidx.lifecycle.ViewModel

class InstructionViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}