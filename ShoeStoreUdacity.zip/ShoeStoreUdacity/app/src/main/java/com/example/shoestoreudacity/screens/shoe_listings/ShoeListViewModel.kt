package com.example.shoestoreudacity.screens.shoe_listings

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class ShoeListViewModel : ViewModel() {
    // TODO: Implement the ViewModel

    private var _listOfShoes = MutableLiveData<List<String>>()
    val listOfShoes: LiveData<List<String>> get() = _listOfShoes
}