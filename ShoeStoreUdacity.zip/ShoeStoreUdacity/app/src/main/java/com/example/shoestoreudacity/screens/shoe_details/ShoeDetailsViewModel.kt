package com.example.shoestoreudacity.screens.shoe_details

import androidx.lifecycle.ViewModel

class ShoeDetailsViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}